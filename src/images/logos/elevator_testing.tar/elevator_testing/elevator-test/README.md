## How to Use

Run ```make``` to generate the executables ```producer``` and ```consumer```.

The executable takes the following arguments respectively.
```
./producer [num_of_passengers]
./consumer [flag]
```
The consumer ```flags``` are as such ```--start``` to start the elevator and
```--stop``` to stop the elevator.